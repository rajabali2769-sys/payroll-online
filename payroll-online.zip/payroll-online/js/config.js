// 1. In Supabase: Project Settings → API
// 2. Paste the Project URL and the "anon / public" key below. (The anon key is designed to be public —
//    your data is protected by login + the row-level security rules in supabase/schema.sql.)
export const SUPABASE_URL = 'https://YOUR-PROJECT-REF.supabase.co';
export const SUPABASE_ANON_KEY = 'YOUR-ANON-PUBLIC-KEY';

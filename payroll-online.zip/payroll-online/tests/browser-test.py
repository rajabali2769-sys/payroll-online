import pathlib, sys, time, json, subprocess, tempfile
from playwright.sync_api import sync_playwright

# usage: python3 tests/browser-test.py <monthly.xlsm> <fortnightly.xlsx>
ROOT = pathlib.Path(__file__).resolve().parent.parent; SHOTS = pathlib.Path(tempfile.gettempdir()) / 'payroll-shots'; SHOTS.mkdir(exist_ok=True)
MONTHLY = sys.argv[1] if len(sys.argv) > 2 else '/mnt/user-data/uploads/September_Monthly_2026.xlsm'
FORT = sys.argv[2] if len(sys.argv) > 2 else '/mnt/user-data/uploads/New_Fortnightly_TimeSheet_Record_18th_September.xlsx'
server = subprocess.Popen([sys.executable, '-m', 'http.server', '8123', '--directory', str(ROOT)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL); time.sleep(1.2)
mock_js = (ROOT / 'tests/mock-supabase.js').read_text()
xlsx_js = ROOT / 'node_modules/xlsx/dist/xlsx.full.min.js'
errors, results = [], []
def check(ok, msg, extra=''):
    results.append(ok); print(f"  {'✓' if ok else '✗'} {msg} {extra}")

with sync_playwright() as p:
    b = p.chromium.launch()
    page = b.new_context(viewport={'width': 1500, 'height': 920}).new_page()
    page.on('console', lambda m: errors.append(m.text) if m.type == 'error' and 'favicon' not in m.text else None)
    page.on('pageerror', lambda e: errors.append('PAGEERROR ' + str(e)))
    page.route('**/esm.sh/**', lambda r: r.fulfill(body=mock_js, content_type='application/javascript'))
    page.route('**/cdnjs.cloudflare.com/**', lambda r: r.fulfill(path=str(xlsx_js), content_type='application/javascript'))
    page.route('**/fonts.*/**', lambda r: r.fulfill(status=200, body='', content_type='text/css'))
    page.route('**/js/config.js', lambda r: r.fulfill(body="export const SUPABASE_URL='https://t.supabase.co'; export const SUPABASE_ANON_KEY='anon';", content_type='application/javascript'))
    shot = lambda n: page.screenshot(path=str(SHOTS / f'{n}.png'))

    print('1 · first run, empty')
    page.goto('http://localhost:8123/'); page.wait_for_selector('.shell')
    check('No payroll data yet' in page.inner_text('.main'), 'empty state shown to a new database'); shot('01-empty')

    print('2 · import both real files through the website')
    page.click('a[data-page=import]'); page.wait_for_selector('.drop')
    t0 = time.time(); page.set_input_files('input[type=file]', [MONTHLY, FORT])
    page.wait_for_function("document.querySelectorAll('.file-card button').length >= 2", timeout=120000)
    check(True, f'both files parsed in the browser in {time.time()-t0:.1f}s')
    txt = page.inner_text('#app')
    check('357,560.32' in txt and '84,424.40' in txt, 'preview calculates the same gross as the Excel files (£357,560.32 and £84,424.40)'); check('1,160' in txt and '344' in txt, 'preview shows 1,160 monthly and 344 fortnightly lines')
    shot('02-import-preview')
    for i in range(2):
        page.locator('.file-card button:has-text("Import")').first.click()
        page.wait_for_function(f"document.querySelectorAll('.file-card .notice').length >= {i+1} && document.body.innerText.includes('Imported')", timeout=180000)
        page.wait_for_timeout(300)
    check(page.inner_text('#app').count('Imported ') >= 2, 'both imports completed')
    db = page.evaluate("({runs: __mock.db.pay_runs.map(r=>[r.stream,r.label,r.status]), lines: __mock.db.payroll_lines.length, weeks: __mock.db.line_weeks.length, days: __mock.db.daily_hours.length, periods: __mock.db.pay_periods.length, audit: __mock.db.audit_log.length})")
    print('   db:', json.dumps(db)); check(db['lines'] == 1504 and all(r[2] == 'ready' for r in db['runs']), 'database holds 1,504 lines and every run is ready')
    check(db['audit'] <= 4, 'import logged once per file, not per row', f"({db['audit']} audit rows)")

    print('3 · dashboard')
    page.goto('http://localhost:8123/#/dashboard'); page.wait_for_selector('.kpi'); page.wait_for_timeout(300)
    page.evaluate("document.querySelector('.page-head select').selectedIndex = [...document.querySelectorAll('.page-head select option')].findIndex(o=>o.textContent.startsWith('Monthly')); document.querySelector('.page-head select').dispatchEvent(new Event('change'))")
    page.wait_for_function("document.body.innerText.includes('357,560.32')", timeout=15000)
    check(True, 'dashboard gross for monthly run = £357,560.32 (same as Excel)'); shot('03-dashboard')

    print('4 · payroll grid')
    page.goto('http://localhost:8123/#/payroll'); page.wait_for_selector('table.t tbody tr'); page.wait_for_timeout(500)
    n = page.locator('table.t tbody tr').count(); check(n == 1160, f'monthly grid shows all {n} lines'); shot('04-payroll')
    heads = [x.lower() for x in page.locator('table.t thead th').all_inner_texts()]; gi, ai = heads.index('gross pay'), heads.index('addition')
    gross_before = page.locator('table.t tbody tr').first.locator('td').nth(gi).inner_text()
    page.locator('table.t tbody tr').first.locator('td').nth(ai).click()
    page.keyboard.press('Control+A'); page.keyboard.type('25'); page.keyboard.press('Enter'); page.wait_for_timeout(500)
    gross_after = page.locator('table.t tbody tr').first.locator('td').nth(gi).inner_text()
    check(gross_before != gross_after, 'editing Addition recalculates Gross pay', f'{gross_before} → {gross_after}')
    check(page.evaluate("__mock.db.audit_log.some(a=>a.table_name==='payroll_lines' && a.new_data && a.new_data.addition===25)"), 'the edit is saved and audited')
    page.select_option('.toolbar select >> nth=0', label='24th'); page.wait_for_timeout(300)
    n24 = page.locator('table.t tbody tr').count(); check(0 < n24 < 1160, f'pay date filter works ({n24} lines on the 24th)')
    page.select_option('.toolbar select >> nth=0', label='All'); page.fill('.toolbar input[type=search]', 'Dixon'); page.wait_for_timeout(500)
    nd = page.locator('table.t tbody tr').count(); check(0 < nd < 200 and all('dixon' in x.lower() for x in page.locator('table.t tbody tr td:first-child').all_inner_texts()), f'search finds only "Dixon" lines ({nd})'); page.fill('.toolbar input[type=search]', ''); page.wait_for_timeout(400)
    page.locator('.chips .chip').nth(1).click(); page.wait_for_timeout(300)
    check('hours (selected)' in ' '.join(page.locator('table.t thead th').all_inner_texts()).lower(), 'turning a week off adds "Hours (selected)" and "Est. pay (selected)"'); shot('05-payroll-weeks')
    page.locator('.chips .chip:has-text("All")').click()

    print('5 · line drawer')
    page.locator('table.t tbody tr').first.locator('a').first.click(); page.wait_for_selector('.drawer h2'); page.wait_for_timeout(500); shot('06-drawer')
    check(page.locator('.drawer .daygrid').count() >= 1, 'drawer shows weekly figures and day-by-day hours')
    page.locator('.drawer table.t tbody tr').first.locator('input[type=number]').first.fill('9'); page.locator('.drawer table.t tbody tr').first.locator('input[type=number]').first.dispatch_event('change'); page.wait_for_timeout(500)
    check(page.evaluate("__mock.db.audit_log.some(a=>a.table_name==='line_weeks')"), 'editing a week inside the drawer is saved and audited')
    page.keyboard.press('Escape'); page.wait_for_timeout(200)

    print('6 · live sync (another user changes a number)')
    target = page.evaluate("(()=>{const l=__mock.db.payroll_lines.find(x=>x.run_id===__mock.db.pay_runs.find(r=>r.stream==='monthly').id && x.contract_type==='Hourly' && x.addition===0); return l.id})()")
    before = page.locator(f'tr[data-id="{target}"]').first.inner_text() if page.locator(f'tr[data-id="{target}"]').count() else ''
    page.evaluate(f"(()=>{{const l=__mock.db.payroll_lines.find(x=>x.id==='{target}'); const old={{...l}}; l.addition=111; __mock.emit('payroll_lines','UPDATE',{{...l}},old);}})()")
    page.wait_for_timeout(1500)
    after = page.locator(f'tr[data-id="{target}"]').first.inner_text()
    check('111.00' in after and before != after, "another user's edit appears in this browser without a refresh"); 

    print('7 · explorer / calendar / history / users / projects')
    for name, sel in [('explorer', 'table.t tbody tr'), ('calendar', 'table.t tbody tr'), ('history', 'table.t tbody tr'), ('users', 'table.t tbody tr'), ('projects', 'table.t tbody tr')]:
        page.goto(f'http://localhost:8123/#/{name}'); page.wait_for_selector(sel, timeout=15000); page.wait_for_timeout(600); shot(f'07-{name}')
        check(page.locator(sel).count() > 0, f'{name} page renders rows ({page.locator(sel).count()})')
    page.goto('http://localhost:8123/#/explorer'); page.wait_for_selector('table.t tbody tr')
    page.locator('.chip:has-text("LWD window")').click(); page.wait_for_timeout(800)
    check('hours' in page.inner_text('.main'), 'explorer quick-pick of the LWD reconciliation window works'); shot('08-explorer-lwd')
    page.select_option('.card.pad select >> nth=0', 'week'); page.wait_for_timeout(600)
    rows_w = page.locator('table.t tbody tr').count(); check(rows_w >= 3, f'explorer grouped by week ({rows_w} weeks)')

    print('8 · fortnightly run')
    page.goto('http://localhost:8123/#/payroll'); page.wait_for_selector('table.t tbody tr')
    page.evaluate("(()=>{const s=document.querySelector('.page-head select'); s.selectedIndex=[...s.options].findIndex(o=>o.textContent.startsWith('Fortnightly')); s.dispatchEvent(new Event('change'))})()")
    page.wait_for_function("document.querySelectorAll('table.t tbody tr').length === 344", timeout=15000)
    check(True, 'fortnightly run shows 344 lines'); shot('09-fortnightly')

    b.close()
server.terminate()
print('\nconsole/page errors:', errors if errors else 'none')
print(f'{sum(results)}/{len(results)} checks passed')
sys.exit(0 if all(results) and not errors else 1)

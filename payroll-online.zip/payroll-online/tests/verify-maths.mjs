// Proves the new maths reproduces the numbers your Excel files already contain.
import XLSX from 'xlsx';
import fs from 'fs';
import { parseWorkbook } from '../js/parsers.js';
import { calcLine } from '../js/calc.js';
const close = (a, b) => Math.abs((a ?? 0) - (b ?? 0)) < 0.011;
let failures = 0;
for (const f of process.argv.slice(2)) {
  const wb = XLSX.read(fs.readFileSync(f), { type: 'buffer' });
  const p = parseWorkbook(XLSX, wb, f.split('/').pop());
  const pairs = p.stream === 'monthly'
    ? [['actual', 'actual'], ['leave', 'leave'], ['over', 'over'], ['less', 'less'], ['hourly', 'hourly'], ['gross', 'gross'], ['budgeted', 'budgeted'], ['diff', 'diff']]
    : [['gross', 'gross'], ['budgeted', 'budgeted']];
  const bad = {}; const examples = {}; let xlsGross = 0, ourGross = 0, n = 0;
  for (const l of p.lines) {
    const r = calcLine(l, p.stream); n++;
    xlsGross += l.check.gross ?? 0; ourGross += r.gross;
    for (const [mine, theirs] of pairs) {
      if (l.check[theirs] === null || l.check[theirs] === undefined) continue;
      if (!close(r[mine], l.check[theirs])) {
        bad[mine] = (bad[mine] || 0) + 1;
        (examples[mine] ||= []).length < 3 && examples[mine].push(`row ${l.source_row} ${l.employee_name}: ours ${r[mine].toFixed(2)} vs excel ${l.check[theirs]}`);
      }
    }
  }
  console.log(`\n== ${p.source_file}: ${n} lines | gross  ours £${ourGross.toFixed(2)}  excel £${xlsGross.toFixed(2)}`);
  console.log(Object.keys(bad).length ? ' MISMATCHES ' + JSON.stringify(bad) : ' all checked columns match Excel');
  for (const k in examples) console.log('  ', k, examples[k].join(' | '));
  failures += Object.keys(bad).length;
}
process.exit(failures ? 1 : 0);

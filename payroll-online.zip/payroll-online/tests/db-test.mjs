// Runs supabase/schema.sql in an in-memory Postgres (PGlite), loads your REAL September files through the
// same parsers the website uses, and proves the database view reproduces the Excel numbers + security + audit.
import { PGlite } from '@electric-sql/pglite';
import XLSX from 'xlsx';
import fs from 'fs';
import crypto from 'crypto';
import { parseWorkbook, normKey } from '../js/parsers.js';

const files = process.argv.slice(2);
for (const ev of ['unhandledRejection','uncaughtException']) process.on(ev, (e) => { console.log(' ✗ ERROR:', String(e && e.message || e).slice(0, 300)); process.exit(1); });
const db = new PGlite();
let pass = 0, fail = 0;
const ok = (cond, msg, extra = '') => { cond ? pass++ : fail++; console.log(`${cond ? ' ✓' : ' ✗'} ${msg}${extra ? '  ' + extra : ''}`); };

// --- minimal Supabase stand-ins so the schema runs outside Supabase
await db.exec(`
  create role anon nologin; create role authenticated nologin; create role service_role nologin;
  create schema auth;
  create table auth.users (id uuid primary key default gen_random_uuid(), email text, raw_user_meta_data jsonb default '{}'::jsonb);
  create function auth.uid() returns uuid language sql stable as $$ select nullif(current_setting('request.jwt.claim.sub', true),'')::uuid $$;
  create publication supabase_realtime;
`);
const schema = fs.readFileSync(new URL('../supabase/schema.sql', import.meta.url), 'utf8');
await db.exec(schema);
await db.exec(schema);   // idempotent re-run
ok(true, 'schema.sql applies cleanly, and applies a second time (idempotent)');
await db.exec(`grant usage on schema public, auth to anon, authenticated;
  grant all on all tables in schema public to authenticated; grant all on all sequences in schema public to authenticated;
  grant execute on all functions in schema public to authenticated; grant select on all tables in schema public to anon;`);

// --- users: first = admin, next = viewer
const u1 = crypto.randomUUID(), u2 = crypto.randomUUID(), u3 = crypto.randomUUID();
for (const [id, e] of [[u1, 'admin@crystal.test'], [u2, 'viewer@crystal.test'], [u3, 'editor@crystal.test']])
  await db.query(`insert into auth.users (id,email) values ($1,$2)`, [id, e]);
await db.query(`update public.profiles set role='editor' where id=$1`, [u3]);
let roles = (await db.query(`select email, role from public.profiles order by email`)).rows;
ok(roles.find(r => r.email === 'admin@crystal.test').role === 'admin' && roles.find(r => r.email === 'viewer@crystal.test').role === 'viewer',
   'first sign-in becomes admin, later ones are viewers');
const as = async (uid) => { await db.exec('reset role'); if (uid) { await db.query(`select set_config('request.jwt.claim.sub',$1,false)`, [uid]); await db.exec('set role authenticated'); } };

// --- import each real file through the same shape the website sends
const importFile = async (f) => {
  const wb = XLSX.read(fs.readFileSync(f), { type: 'buffer' });
  const p = parseWorkbook(XLSX, wb, f.split('/').pop());
  await as(u3);
  const runId = crypto.randomUUID();
  await db.query(`insert into pay_runs (id,stream,label,period_start,period_end,source_file,status) values ($1,$2,$3,$4,$5,$6,'importing')`,
    [runId, p.stream, `${p.stream} test`, p.period_start, p.period_end, p.source_file]);
  const L = [], W = [], D = [];
  for (const l of p.lines) {
    l.id = crypto.randomUUID();
    L.push({ id: l.id, run_id: runId, project_name: l.project, site_name: l.site, employee_name: l.employee_name, ni_number: l.ni, blip_site: l.blip_site,
      status: l.status, contract_type: l.contract_type, hourly_rate: l.hourly_rate, budgeted_hours: l.budgeted_hours, fixed_pay: l.fixed_pay,
      leave_pay: l.leave_pay, addition: l.addition, deduction: l.deduction, weeks_reconciled: l.weeks_reconciled, remarks: l.remarks,
      comments: l.comments, pay_group: l.pay_group, extra: l.extra, created_at: new Date().toISOString(), updated_at: new Date().toISOString() });
    for (const w of l.weeks) W.push({ line_id: l.id, ...w });
    for (const d of l.days) D.push({ line_id: l.id, work_date: d.d, hours: d.hours, note: d.note });
  }
  const t0 = Date.now();
  await db.query(`insert into payroll_lines select * from jsonb_populate_recordset(null::payroll_lines, $1::jsonb)`, [JSON.stringify(L)]);
  await db.query(`insert into line_weeks select * from jsonb_populate_recordset(null::line_weeks, $1::jsonb)`, [JSON.stringify(W)]);
  await db.query(`insert into daily_hours select * from jsonb_populate_recordset(null::daily_hours, $1::jsonb)`, [JSON.stringify(D)]);
  await db.query(`update pay_runs set status='ready' where id=$1`, [runId]);
  console.log(`\n== ${p.source_file}: inserted ${L.length} lines, ${W.length} weeks, ${D.length} days in ${Date.now() - t0} ms`);
  return { p, runId };
};

const imported = [];
for (const f of files) imported.push(await importFile(f));
const auditAfterImport = (await db.query(`select count(*)::int c from audit_log where action in ('INSERT','UPDATE','DELETE') and table_name <> 'pay_runs'`)).rows[0].c;
ok(auditAfterImport === 0, 'bulk import does not flood the audit log', `(${auditAfterImport} per-row entries)`);

// --- the view must equal the Excel results
const close = (a, b) => Math.abs((+a || 0) - (+b || 0)) < 0.011;
for (const { p, runId } of imported) {
  await as(u2);
  const rows = (await db.query(`select * from v_payroll_lines where run_id=$1`, [runId])).rows;
  const byId = new Map(rows.map(r => [r.id, r]));
  let bad = 0, gx = 0, gv = 0;
  for (const l of p.lines) {
    const r = byId.get(l.id); gv += +r.gross_pay; gx += l.check.gross ?? 0;
    const pairs = p.stream === 'monthly'
      ? [[r.actual_hours, l.check.actual], [r.leave_hours, l.check.leave], [r.over_hours, l.check.over], [r.less_hours, l.check.less], [r.hourly_pay, l.check.hourly], [r.gross_pay, l.check.gross]]
      : [[r.gross_pay, l.check.gross]];
    if (pairs.some(([a, b]) => b != null && !close(a, b))) bad++;
  }
  ok(bad === 0, `${p.stream}: view matches Excel on every line`, `gross £${gv.toFixed(2)} vs Excel £${gx.toFixed(2)}, ${bad} differing lines`);
}

const vw = (await db.query(`select count(*)::int c from v_line_weeks where run_id=$1`, [imported[0].runId])).rows[0].c;
ok(vw > 1000, 'v_line_weeks view returns the weekly rows of a run', `(${vw})`);

// --- security
await as(u2);   // viewer
const nRead = (await db.query(`select count(*)::int c from payroll_lines`)).rows[0].c;
ok(nRead > 1000, 'viewer can read payroll data', `(${nRead} lines)`);
let blocked = false;
try { await db.query(`update payroll_lines set addition = 999 where id = (select id from payroll_lines limit 1)`); const c = (await db.query(`select count(*)::int c from payroll_lines where addition = 999`)).rows[0].c; blocked = c === 0; } catch { blocked = true; }
ok(blocked, 'viewer cannot change payroll data');
blocked = false;
try { await db.query(`select count(*) from audit_log`); const c = (await db.query(`select count(*)::int c from audit_log`)).rows[0].c; blocked = c === 0; } catch { blocked = true; }
ok(blocked, 'viewer cannot read the audit log');
await as(null);
await db.exec('set role anon'); let anonSees = 0; try { anonSees = (await db.query(`select count(*)::int c from payroll_lines`)).rows[0].c; } catch { anonSees = 0; }
ok(anonSees === 0, 'someone who is not logged in sees nothing');

// --- editing recalculates for everyone + audit trail
await as(u3);
const target = (await db.query(`select id, employee_name, gross_pay, addition from v_payroll_lines where contract_type='Hourly' and run_id=$1 limit 1`, [imported[0].runId])).rows[0];
await db.query(`update payroll_lines set addition = addition + 50, hourly_rate = hourly_rate + 1 where id=$1`, [target.id]);
await as(u2);
const after = (await db.query(`select gross_pay from v_payroll_lines where id=$1`, [target.id])).rows[0];
ok(+after.gross_pay > +target.gross_pay + 49.99, 'an edit made by one user changes the calculated gross for another', `£${(+target.gross_pay).toFixed(2)} → £${(+after.gross_pay).toFixed(2)}`);
await as(u1);
const au = (await db.query(`select user_email, table_name, action, context, old_data, new_data from audit_log where table_name='payroll_lines'`)).rows;
ok(au.length === 1 && au[0].user_email === 'editor@crystal.test' && au[0].new_data.addition !== undefined && au[0].old_data.hourly_rate !== undefined,
   'audit log records who changed what (old → new)', JSON.stringify(au[0]?.new_data));

// week edit is audited too
await as(u3);
const wk = (await db.query(`select line_id, week_start from line_weeks where line_id=$1 limit 1`, [target.id])).rows[0];
if (wk) { await db.query(`update line_weeks set delivered = delivered + 2 where line_id=$1 and week_start=$2`, [wk.line_id, wk.week_start]);
  await as(u1); ok((await db.query(`select count(*)::int c from audit_log where table_name='line_weeks'`)).rows[0].c === 1, 'weekly-hours edit is audited'); }

// --- explorer by arbitrary dates
await as(u2);
const m = imported.find(i => i.p.stream === 'monthly');
const ex = (await db.query(`select * from explore_hours($1::date,$2::date,'week')`, ['2026-08-31', '2026-09-27'])).rows;
ok(ex.length >= 4 && ex.every(r => +r.hours > 0), 'explore_hours groups any date range by week', ex.map(r => `${r.grp}: ${(+r.hours).toFixed(0)}h`).join(' | '));
const one = (await db.query(`select * from explore_hours('2026-09-01','2026-09-01','day')`)).rows;
ok(one.length === 1 && one[0].grp === '2026-09-01', 'explore_hours for a single day');
const byGroup = (await db.query(`select * from explore_hours('2026-08-31','2026-09-27','pay_group',null,$1)`, [m.runId])).rows;
ok(byGroup.length >= 3, 'explore_hours can be limited to one run and grouped by pay date', byGroup.map(r => r.grp).join(', '));

// --- run summary & replacing a run
const sum = (await db.query(`select pay_group, lines, round(gross::numeric,2) gross from v_run_summary where run_id=$1 order by pay_group`, [m.runId])).rows;
ok(sum.length >= 5, 'run summary by pay-date group', sum.map(s => `${s.pay_group}:${s.lines}`).join(' '));
await as(u3);
await db.query(`select clear_run($1)`, [m.runId]);
ok((await db.query(`select count(*)::int c from payroll_lines where run_id=$1`, [m.runId])).rows[0].c === 0, 'clear_run empties a run for re-import (editor allowed)');
await as(u2);
let delBlocked = false; try { await db.query(`select delete_run($1)`, [m.runId]); } catch { delBlocked = true; }
ok(delBlocked, 'viewer cannot delete a run');
await as(u3); delBlocked = false; try { await db.query(`select delete_run($1)`, [m.runId]); } catch { delBlocked = true; }
ok(delBlocked, 'editor cannot delete a run (admin only)');
await as(u1); await db.query(`select delete_run($1)`, [m.runId]);
ok((await db.query(`select count(*)::int c from pay_runs where id=$1`, [m.runId])).rows[0].c === 0, 'admin can delete a run');

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);

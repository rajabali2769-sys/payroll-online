// A tiny in-memory stand-in for supabase-js, used ONLY by the browser test. Mirrors the SQL views in schema.sql.
const uuid = () => crypto.randomUUID();
const db = { pay_runs: [], payroll_lines: [], line_weeks: [], daily_hours: [], pay_periods: [], projects: [], project_aliases: [], employees: [], audit_log: [],
  profiles: [{ id: 'u-admin', email: 'rajab@crystalfm.co.uk', full_name: 'Rajab', role: 'admin', created_at: '2026-10-01T09:00:00Z' }, { id: 'u-2', email: 'aliza@crystalfm.co.uk', full_name: 'Aliza', role: 'editor', created_at: '2026-10-02T09:00:00Z' }] };
const handlers = [];
let auditSeq = 0;
const mondayOf = (iso) => { const d = new Date(iso + 'T00:00:00Z'); return new Date(d.getTime() - ((d.getUTCDay() + 6) % 7) * 86400000).toISOString().slice(0, 10); };
const DEFAULTS = {
  pay_runs: () => ({ id: uuid(), status: 'ready', created_at: new Date().toISOString() }),
  payroll_lines: () => ({ id: uuid(), hourly_rate: 0, budgeted_hours: 0, leave_pay: 0, addition: 0, deduction: 0, extra: {}, fixed_pay: null, weeks_reconciled: null, created_at: new Date().toISOString(), updated_at: new Date().toISOString() }),
  line_weeks: () => ({ delivered: 0, leave: 0, budget: 0, in_window: true, variance_override: null }),
  daily_hours: () => ({ hours: null, note: null }), pay_periods: () => ({ id: uuid(), reconcile_from: null, reconcile_to: null, pay_date: null }),
  projects: () => ({ id: uuid(), created_at: new Date().toISOString(), pay_group: null, manager: null, collection_type: null }), employees: () => ({ id: uuid(), created_at: new Date().toISOString() }), project_aliases: () => ({}),
};
const PK = { pay_runs: ['id'], payroll_lines: ['id'], line_weeks: ['line_id', 'week_start'], daily_hours: ['line_id', 'work_date'], pay_periods: ['id'], projects: ['id'], employees: ['id'], project_aliases: ['alias_key'], profiles: ['id'] };

function computeLines() {
  const runs = new Map(db.pay_runs.map((r) => [r.id, r])), wk = new Map();
  for (const w of db.line_weeks) { if (!wk.has(w.line_id)) wk.set(w.line_id, []); wk.get(w.line_id).push(w); }
  return db.payroll_lines.map((l) => {
    const r = runs.get(l.run_id) || {}, ws = wk.get(l.id) || [];
    let actual = 0, leave = 0, over = 0, less = 0, bsum = 0;
    for (const w of ws) { actual += +w.delivered; leave += +w.leave; bsum += +w.budget; if (w.in_window) { const v = w.variance_override != null ? +w.variance_override : +w.delivered + +w.leave - +w.budget; if (v > 0) over += v; else less += v; } }
    const budgetHours = r.stream === 'monthly' ? (l.weeks_reconciled == null ? 0 : l.budgeted_hours * l.weeks_reconciled) : bsum;
    const hourly = ['hourly', 'cover'].includes(String(l.contract_type || '').toLowerCase()) ? (actual + leave) * l.hourly_rate : 0;
    const gross = (l.fixed_pay ?? 0) + hourly + +l.addition + +l.leave_pay - +l.deduction;
    const budgeted = l.fixed_pay != null ? +l.fixed_pay : budgetHours * l.hourly_rate, difference = gross - budgeted;
    return { ...l, stream: r.stream, run_label: r.label, actual_hours: actual, leave_hours: leave, over_hours: over, less_hours: less, budget_hours_total: budgetHours, hourly_pay: hourly, gross_pay: gross, budgeted_pay: budgeted, difference, budget_status: difference > 0.5 ? 'Over' : difference < -0.5 ? 'Under' : 'Within' };
  });
}
function view(name) {
  if (name === 'v_payroll_lines') return computeLines();
  if (name === 'v_line_weeks') { const m = new Map(db.payroll_lines.map((l) => [l.id, l.run_id])); return db.line_weeks.map((w) => ({ ...w, run_id: m.get(w.line_id) })); }
  if (name === 'v_run_summary') {
    const g = new Map();
    for (const l of computeLines()) { const k = l.run_id + '|' + (l.pay_group || 'Unassigned'); const s = g.get(k) || { run_id: l.run_id, pay_group: l.pay_group || 'Unassigned', lines: 0, emp: new Set(), actual_hours: 0, gross: 0, budgeted: 0, difference: 0, over_lines: 0, under_lines: 0 };
      s.lines++; s.emp.add(l.employee_id || l.employee_name); s.actual_hours += l.actual_hours; s.gross += l.gross_pay; s.budgeted += l.budgeted_pay; s.difference += l.difference; if (l.budget_status === 'Over') s.over_lines++; if (l.budget_status === 'Under') s.under_lines++; g.set(k, s); }
    return [...g.values()].map((s) => ({ ...s, employees: s.emp.size }));
  }
  if (name === 'v_daily') { const L = new Map(computeLines().map((l) => [l.id, l])); return db.daily_hours.map((d) => { const l = L.get(d.line_id); return l ? { ...d, week_start: mondayOf(d.work_date), run_id: l.run_id, project_name: l.project_name, site_name: l.site_name, employee_name: l.employee_name, employee_id: l.employee_id, pay_group: l.pay_group, contract_type: l.contract_type, hourly_rate: l.hourly_rate, stream: l.stream } : null; }).filter(Boolean); }
  return db[name];
}
const emit = (table, type, row, old) => handlers.filter((h) => h.table === table).forEach((h) => setTimeout(() => h.cb({ eventType: type, new: row || {}, old: old || {} }), 20));
const runOf = (t, row) => (t === 'payroll_lines' ? row.run_id : db.payroll_lines.find((l) => l.id === row.line_id)?.run_id);
function audit(t, action, oldRow, newRow) {
  if (!['payroll_lines', 'line_weeks', 'daily_hours'].includes(t)) return;
  const row = newRow || oldRow, runId = runOf(t, row), run = db.pay_runs.find((r) => r.id === runId);
  if (!run || run.status === 'importing') return;
  const line = t === 'payroll_lines' ? row : db.payroll_lines.find((l) => l.id === row.line_id); if (!line) return;
  let o = null, n = null;
  if (action === 'UPDATE') { o = {}; n = {}; for (const k of Object.keys(newRow)) if (!['updated_at'].includes(k) && JSON.stringify(oldRow[k]) !== JSON.stringify(newRow[k])) { o[k] = oldRow[k]; n[k] = newRow[k]; } if (!Object.keys(n).length) return; } else if (action === 'INSERT') n = row; else o = row;
  db.audit_log.push({ id: ++auditSeq, at: new Date().toISOString(), user_id: 'u-admin', user_email: 'rajab@crystalfm.co.uk', table_name: t, row_id: t === 'payroll_lines' ? row.id : row.line_id + '/' + (row.week_start || row.work_date), action, run_id: runId, context: line.employee_name + ' · ' + line.project_name, old_data: o, new_data: n });
}
function cascadeDelete(t, rows) {
  const ids = new Set(rows.map((r) => r.id));
  if (t === 'pay_runs') { const lines = db.payroll_lines.filter((l) => ids.has(l.run_id)); cascadeDelete('payroll_lines', lines); db.payroll_lines = db.payroll_lines.filter((l) => !ids.has(l.run_id)); db.pay_periods = db.pay_periods.filter((p) => !ids.has(p.run_id)); }
  if (t === 'payroll_lines') { db.line_weeks = db.line_weeks.filter((w) => !ids.has(w.line_id)); db.daily_hours = db.daily_hours.filter((d) => !ids.has(d.line_id)); }
}
class Q {
  constructor(t) { this.t = t; this.op = 'select'; this.f = []; this.ord = []; this.rng = null; this.lim = null; this.ret = false; this.one = null; this.opts = {}; }
  select() { if (this.op !== 'select') this.ret = true; return this; }
  eq(k, v) { this.f.push((r) => r[k] === v); return this; } neq(k, v) { this.f.push((r) => r[k] !== v); return this; }
  in(k, a) { this.f.push((r) => a.includes(r[k])); return this; } lt(k, v) { this.f.push((r) => r[k] < v); return this; }
  like(k, p) { const re = new RegExp('^' + p.replace(/[.*+?^${}()|[\]\\]/g, '\\$&').replace(/%/g, '.*') + '$'); this.f.push((r) => re.test(String(r[k] ?? ''))); return this; }
  order(c, o = {}) { this.ord.push([c, o.ascending !== false]); return this; } range(a, b) { this.rng = [a, b]; return this; } limit(n) { this.lim = n; return this; }
  maybeSingle() { this.one = 'maybe'; return this; } single() { this.one = 'single'; return this; }
  insert(r) { this.op = 'insert'; this.payload = [].concat(r); return this; } update(p) { this.op = 'update'; this.payload = p; return this; }
  upsert(r, o = {}) { this.op = 'upsert'; this.payload = [].concat(r); this.opts = o; return this; } delete() { this.op = 'delete'; return this; }
  then(res, rej) { return Promise.resolve().then(() => this.run()).then(res, rej); }
  shape(rows) { if (this.one) { if (rows.length > 1 && this.one === 'single') return { data: null, error: { message: 'multiple rows' } }; if (!rows.length) return this.one === 'maybe' ? { data: null, error: null } : { data: null, error: { message: 'no rows' } }; return { data: rows[0], error: null }; } return { data: rows, error: null }; }
  insertOne(row) {
    const t = this.t, full = { ...(DEFAULTS[t] ? DEFAULTS[t]() : {}), ...row };
    if (t === 'pay_runs' && db.pay_runs.some((r) => r.stream === full.stream && r.label === full.label)) return { error: { message: 'duplicate key value violates unique constraint "pay_runs_stream_label_key"' } };
    if (t === 'projects' && db.projects.some((p) => p.name_key === full.name_key)) return { error: { message: 'duplicate key value violates unique constraint "projects_name_key_key"' } };
    if (t === 'employees' && full.ni_number && db.employees.some((e) => e.ni_number === full.ni_number)) return { error: { message: 'duplicate key value violates unique constraint "employees_ni_uniq"' } };
    if (t === 'pay_periods' && db.pay_periods.some((p) => p.run_id === full.run_id && p.pay_group === full.pay_group)) return { error: { message: 'duplicate key' } };
    db[t].push(full); audit(t, 'INSERT', null, full); emit(t, 'INSERT', full); return { row: full };
  }
  run() {
    const t = this.t, isView = t.startsWith('v_');
    if (this.op === 'select') {
      let rows = (isView ? view(t) : db[t]).filter((r) => this.f.every((p) => p(r)));
      for (const [c, asc] of [...this.ord].reverse()) rows = [...rows].sort((a, b) => { const x = a[c], y = b[c]; if (x === y) return 0; if (x === null || x === undefined) return 1; if (y === null || y === undefined) return -1; return (x > y ? 1 : -1) * (asc ? 1 : -1); });
      if (this.rng) rows = rows.slice(this.rng[0], this.rng[1] + 1); if (this.lim) rows = rows.slice(0, this.lim);
      return this.shape(rows.map((r) => ({ ...r })));
    }
    if (this.op === 'insert') { const out = []; for (const r of this.payload) { const x = this.insertOne(r); if (x.error) return x; out.push(x.row); } return this.ret ? this.shape(out) : { data: null, error: null }; }
    if (this.op === 'upsert') {
      const keys = (this.opts.onConflict || (PK[t] || ['id']).join(',')).split(','), out = [];
      for (const r of this.payload) {
        const cur = db[t].find((x) => keys.every((k) => String(x[k]) === String(r[k])));
        if (cur) { const old = { ...cur }; Object.assign(cur, r); audit(t, 'UPDATE', old, { ...cur }); emit(t, 'UPDATE', { ...cur }, old); out.push(cur); } else { const x = this.insertOne(r); if (x.error) return x; out.push(x.row); }
      }
      return this.ret ? this.shape(out) : { data: null, error: null };
    }
    const rows = db[t].filter((r) => this.f.every((p) => p(r)));
    if (this.op === 'update') { for (const r of rows) { const old = { ...r }; Object.assign(r, this.payload); if ('updated_at' in r) r.updated_at = new Date().toISOString(); audit(t, 'UPDATE', old, { ...r }); emit(t, 'UPDATE', { ...r }, old); } return { data: null, error: null }; }
    if (this.op === 'delete') { cascadeDelete(t, rows); db[t] = db[t].filter((r) => !rows.includes(r)); for (const r of rows) { audit(t, 'DELETE', r, null); emit(t, 'DELETE', null, r); } return { data: null, error: null }; }
  }
}
function rpc(name, a) {
  if (name === 'clear_run') { const lines = db.payroll_lines.filter((l) => l.run_id === a.p_run); cascadeDelete('payroll_lines', lines); db.payroll_lines = db.payroll_lines.filter((l) => l.run_id !== a.p_run); return { data: null, error: null }; }
  if (name === 'delete_run') { const r = db.pay_runs.filter((x) => x.id === a.p_run); cascadeDelete('pay_runs', r); db.pay_runs = db.pay_runs.filter((x) => x.id !== a.p_run); emit('pay_runs', 'DELETE', null, r[0]); return { data: null, error: null }; }
  if (name === 'log_import') { db.audit_log.push({ id: ++auditSeq, at: new Date().toISOString(), user_email: 'rajab@crystalfm.co.uk', table_name: 'pay_runs', row_id: a.p_run, action: 'IMPORT', run_id: a.p_run, context: a.p_text }); return { data: null, error: null }; }
  if (name === 'explore_hours') {
    const g = new Map();
    for (const v of view('v_daily')) {
      if (v.work_date < a.p_from || v.work_date > a.p_to) continue; if (a.p_stream && v.stream !== a.p_stream) continue; if (a.p_run && v.run_id !== a.p_run) continue;
      if (a.p_group && v.pay_group !== a.p_group) continue; if (a.p_project && v.project_name !== a.p_project) continue; if (a.p_search && !v.employee_name.toLowerCase().includes(a.p_search.toLowerCase())) continue;
      const k = { project: v.project_name, site: v.site_name || '—', week: v.week_start, day: v.work_date, pay_group: v.pay_group || 'Unassigned' }[a.p_by] ?? v.employee_name;
      const s = g.get(k) || { grp: k, hours: 0, est_pay: 0, emp: new Set(), ln: new Set() };
      s.hours += +v.hours || 0; if (['hourly', 'cover'].includes(String(v.contract_type || '').toLowerCase())) s.est_pay += (+v.hours || 0) * v.hourly_rate; s.emp.add(v.employee_id || v.employee_name); s.ln.add(v.line_id); g.set(k, s);
    }
    return { data: [...g.values()].sort((x, y) => (x.grp > y.grp ? 1 : -1)).map((s) => ({ grp: s.grp, hours: s.hours, est_pay: s.est_pay, employees: s.emp.size, line_count: s.ln.size })), error: null };
  }
  return { data: null, error: { message: 'unknown rpc ' + name } };
}
const session = { user: { id: 'u-admin', email: 'rajab@crystalfm.co.uk' } };
export function createClient() {
  window.__mock = { db, emit };
  return {
    from: (t) => new Q(t), rpc: (n, a) => Promise.resolve(rpc(n, a)),
    auth: { getSession: async () => ({ data: { session } }), signInWithPassword: async () => ({ data: { session }, error: null }), signOut: async () => ({ error: null }), resetPasswordForEmail: async () => ({ error: null }), updateUser: async () => ({ data: {}, error: null }), onAuthStateChange: (cb) => { setTimeout(() => cb('INITIAL_SESSION', session), 0); return { data: { subscription: {} } }; } },
    channel: () => { const ch = { on: (_t, f, cb) => { handlers.push({ table: f.table, cb }); return ch; }, subscribe: (cb) => { setTimeout(() => cb && cb('SUBSCRIBED'), 30); return ch; } }; return ch; }, removeChannel: () => {},
  };
}
